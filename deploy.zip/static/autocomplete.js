// Archivo JavaScript para autocompletado de trabajadores en el formulario principal
// Se usará con un input de texto y AJAX para buscar trabajadores por nombre y empresa
